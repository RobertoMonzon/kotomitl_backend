package com.kotomitl.kotomitl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KotomitlApplication {

	public static void main(String[] args) {
		SpringApplication.run(KotomitlApplication.class, args);
	}

}
