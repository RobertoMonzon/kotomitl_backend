package com.kotomitl.kotomitl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KotomitlApplicationTests {

	@Test
	void contextLoads() {
	}

}
